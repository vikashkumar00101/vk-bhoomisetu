# BhoomiSetu

AI-powered land document assistant — a student-project demo.

## Run locally

This project is currently a self-contained HTML application. Open `index.html` in a modern browser.

## Features

- Responsive single-page interface
- Sample land-record explorer
- Document upload/preview interface
- Document comparison and preliminary issue indicators
- Demo AI assistant interactions
- Browser-local demo storage

## Important limitations

This is a demonstration project. It is not connected to government land-record databases, does not certify ownership, and must not be treated as legal verification. Use synthetic/sample data only.

## Project structure

- `index.html` — complete application (HTML, CSS and JavaScript)
